package com.kaquenduri.prueba01_mqtt.Presentation

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kaquenduri.prueba01_mqtt.R
import com.kaquenduri.prueba01_mqtt.ViewModels.SensorViewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GraficosScreen(
    viewModel: SensorViewModel,
    irHome: () -> Unit
) {
    val mensajeH by viewModel.mensajeHumedad
    val mensajeT by viewModel.mensajeTemperatura
    val mensajeHA by viewModel.mensajeHumedadAire
    
    // Datos actuales de sensores
    val humedadActual = remember(mensajeH) {
        Regex("""\d+""").find(mensajeH)?.value?.toFloatOrNull() ?: 0f
    }
    val temperaturaActual = remember(mensajeT) {
        Regex("""\d+""").find(mensajeT)?.value?.toFloatOrNull() ?: 0f
    }
    val humedadAireActual = remember(mensajeHA) {
        Regex("""\d+""").find(mensajeHA)?.value?.toFloatOrNull() ?: 0f
    }
    
    // Historial de datos para gráficos
    var historialHumedad by remember { mutableStateOf(listOf<Float>()) }
    var historialTemperatura by remember { mutableStateOf(listOf<Float>()) }
    var historialHumedadAire by remember { mutableStateOf(listOf<Float>()) }
    
    // Actualizar historial cuando cambien los valores
    LaunchedEffect(humedadActual, temperaturaActual, humedadAireActual) {
        if (humedadActual > 0f) {
            historialHumedad = (historialHumedad + humedadActual).takeLast(20)
        }
        if (temperaturaActual > 0f) {
            historialTemperatura = (historialTemperatura + temperaturaActual).takeLast(20)
        }
        if (humedadAireActual > 0f) {
            historialHumedadAire = (historialHumedadAire + humedadAireActual).takeLast(20)
        }
    }
    
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.foundation.Image(
                            painter = androidx.compose.ui.res.painterResource(id = R.drawable.ic_plant),
                            contentDescription = "agrocode logo",
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Gráficos • agrocode",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { irHome() }) {
                        Icon(Icons.Default.Home, contentDescription = "Ir a Home", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { 
                        historialHumedad = emptyList()
                        historialTemperatura = emptyList()
                        historialHumedadAire = emptyList()
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Limpiar gráficos", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF2E7D32)
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Valores actuales
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Valores Actuales",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(12.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ValorActualItem("Humedad", humedadActual, "%", Color(0xFF2E7D32))
                            ValorActualItem("Temperatura", temperaturaActual, "°C", Color(0xFFD32F2F))
                            ValorActualItem("Humedad Aire", humedadAireActual, "%", Color(0xFF1976D2))
                        }
                    }
                }
            }
            
            // Gráfico de Humedad
            item {
                GraficoCard(
                    titulo = "Humedad del Suelo",
                    historial = historialHumedad,
                    color = Color(0xFF2E7D32),
                    unidad = "%"
                )
            }
            
            // Gráfico de Temperatura
            item {
                GraficoCard(
                    titulo = "Temperatura del Aire",
                    historial = historialTemperatura,
                    color = Color(0xFFD32F2F),
                    unidad = "°C"
                )
            }
            
            // Gráfico de Humedad del Aire
            item {
                GraficoCard(
                    titulo = "Humedad del Aire",
                    historial = historialHumedadAire,
                    color = Color(0xFF1976D2),
                    unidad = "%"
                )
            }
        }
    }
}

@Composable
fun ValorActualItem(
    nombre: String,
    valor: Float,
    unidad: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = nombre,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "${valor.roundToInt()}$unidad",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
fun GraficoCard(
    titulo: String,
    historial: List<Float>,
    color: Color,
    unidad: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = titulo,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            
            if (historial.isEmpty()) {
                Text(
                    text = "Esperando datos del sensor...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    text = "Último valor: ${historial.last().roundToInt()}$unidad",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                
                GraficoLinea(
                    historial = historial,
                    color = color,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                )
            }
        }
    }
}

@Composable
fun GraficoLinea(
    historial: List<Float>,
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (historial.size < 2) return@Canvas
        
        val maxValor = historial.maxOrNull() ?: 100f
        val minValor = historial.minOrNull() ?: 0f
        val rango = maxValor - minValor
        
        val stepX = size.width / (historial.size - 1)
        
        // Dibujar líneas del gráfico
        for (i in 0 until historial.lastIndex) {
            val x1 = i * stepX
            val x2 = (i + 1) * stepX
            
            val y1 = size.height - ((historial[i] - minValor) / rango) * size.height
            val y2 = size.height - ((historial[i + 1] - minValor) / rango) * size.height
            
            drawLine(
                color = color,
                start = androidx.compose.ui.geometry.Offset(x1, y1),
                end = androidx.compose.ui.geometry.Offset(x2, y2),
                strokeWidth = 3f
            )
        }
        
        // Dibujar puntos
        historial.forEachIndexed { index, valor ->
            val x = index * stepX
            val y = size.height - ((valor - minValor) / rango) * size.height
            
            drawCircle(
                color = color,
                radius = 4f,
                center = androidx.compose.ui.geometry.Offset(x, y)
            )
        }
    }
}
