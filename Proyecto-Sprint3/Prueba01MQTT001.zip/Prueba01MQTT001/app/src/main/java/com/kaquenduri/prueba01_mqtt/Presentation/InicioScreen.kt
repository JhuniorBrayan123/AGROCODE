package com.kaquenduri.prueba01_mqtt.Presentation

import androidx.compose.runtime.Composable
import com.kaquenduri.prueba01_mqtt.ViewModels.InicioViewModel

@Composable
fun InicioScreen(
    viewModel: InicioViewModel
){

}