package com.kaquenduri.prueba01_mqtt.ViewModels

import androidx.lifecycle.ViewModel

class InicioViewModel : ViewModel() {

}